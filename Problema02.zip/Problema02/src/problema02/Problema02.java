/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package problema02;

import java.util.Scanner;

/**
 *
 * @author utpl
 */
public class Problema02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);

        int limite;
        String acumulador = "";
        int numImpares = 0;
        int contador = 1;
        int numero;
        boolean mostrar = true;

        System.out.println("Ingrese el numero total de terminos");
        limite = entrada.nextInt();
        if (limite >= 4 && limite <= 10) {
            while (contador <= limite) {
                System.out.println("Ingrese un numero");
                numero = entrada.nextInt();
                if (numero % 2 == 1) {
                    numImpares = numImpares + 1;
                }
                acumulador = String.format("%s%d\n", acumulador, numero);
                contador = contador + 1;

            }
        } else {
            System.out.println("ERROR DEBE ESTAR DENTRO DEL RANGO DE 4 A 10");
            mostrar = false;
        }
        if (mostrar) {
            acumulador = String.format("Numeros ingresados:\n%sNumeros impares:"
                    + " %d", acumulador, numImpares);

            System.out.printf("%s\n", acumulador);
        }
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package problema01;

import java.util.Scanner;

/**
 *
 * @author utpl
 */
public class Problema01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);

        String cedula;
        double salarioActual;
        double salarioFinal = 0;
        boolean salida = true;
        String respuesta;
        String acumulador = "";

        while (salida) {
            System.out.println("Ingrese el numero de cedula");
            cedula = entrada.nextLine();
            System.out.println("Ingrese su salario actual");
            salarioActual = entrada.nextDouble();
            entrada.nextLine();
            if (salarioActual <= 400 && salarioActual >= 0) {
                salarioFinal = salarioActual * 1.2;
            } else {
                if (salarioActual <= 800 && salarioActual > 400) {
                    salarioFinal = salarioActual * 1.1;
                } else {
                    if (salarioActual <= 1500 && salarioActual > 800) {
                        salarioFinal = salarioActual * 1.05;
                    } else {
                        if (salarioActual > 1500) {
                            salarioFinal = salarioActual * 1.01;
                        } else {
                            System.out.println("El salario deb ser positivo");
                        }
                    }
                }
            }
            acumulador = String.format("%sCédula: %s | salario actual: %.2f | "
                    + "salario nuevo: %.2f\n",
                     acumulador, cedula, salarioActual, salarioFinal);
            System.out.println("si desea salir, escriba 's'");
            respuesta = entrada.nextLine();
            if (respuesta.equals("s")) {
                salida = false;
            }
        }
        System.out.printf("%s", acumulador);
    }
}
